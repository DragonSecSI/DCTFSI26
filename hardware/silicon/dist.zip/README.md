# Emulating Verilog

```sh
verilator --binary --timing --sv -Wall --Wno-WIDTHEXPAND --Wno-WIDTHTRUNC --Wno-INITIALDLY --Wno-CASEINCOMPLETE --Wno-EOFNEWLINE --Wno-DECLFILENAME --Wno-UNUSEDSIGNAL -o Vserver_tb server_tb.sv
```

This creates a binary Vserver_tb that emulates the verilog.
Verilator is the industry standard and is used by pretty much everybody :)

Good luck <3