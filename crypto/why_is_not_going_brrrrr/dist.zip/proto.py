import os
import time
from hashlib import shake_128
from secrets import token_bytes

FLAG = os.environ.get('FLAG', "dctf{????????????????????????????????????").encode()

N = 20
assert N & 1 == 0
mask = (1 << (N*8)) - 1
key1 = shake_128(FLAG + int(time.time()/3000).to_bytes(8)).digest(N)
q = 0xffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a63a36210000000000090563

def filter_k(k, s): return pow(k, s, q) & 0xFF
def filter_2(s): return pow(2, s, q) & 0xFF


def enc1(key, state, msg):
    k = int.from_bytes(key)
    s = int.from_bytes(state)
    c = []
    for _i, b in enumerate(msg):
        s <<= 8
        s &= mask
        t = filter_k(k, s)
        c.append(t ^ b)
        s += t
        s <<= 8
        s &= mask
        s += filter_2(s)        
    return bytes(c)

iv = token_bytes(20)
print(f'alice to bob: {iv.hex()}')
iv = bytes(a ^ b for a, b in zip(iv, bytes.fromhex(input(f'bob to alice: '))))
msg1 = token_bytes(20)
print(f'alice to bob: {enc1(key1, iv, msg1).hex()}')
if msg1 == bytes.fromhex(input(f'what was the message?: ')):
    print('Correct!, now you are warmed up enought for the next stage :).')
else:
    print('You got it wrong, but you can still continue to the next stage :S.')

print('----------------------------------------------------------------')
key2 = shake_128(b'?' + FLAG + int(time.time()/60).to_bytes(8)).digest(N)

def enc2(key, state, msg):
    offset = token_bytes(20)
    k = int.from_bytes(key)
    s = int.from_bytes(state)
    c = []
    for _i, b in enumerate(offset + msg):
        s <<= 8
        s &= mask
        t = filter_k(k, s)
        c.append(t ^ b)
        s += t
        s <<= 8
        s &= mask
        s += filter_2(s)
    return bytes(c)

iv = token_bytes(20)
print(f'alice to bob: {iv.hex()}')
iv = bytes(a ^ b for a, b in zip(iv, bytes.fromhex(input(f'bob to alice: '))))
print(f'alice to bob: {enc2(key2, iv, FLAG).hex()}')

print('----------------------------------------------------------------')
key3 = shake_128(b'!' +FLAG + int(time.time()/60).to_bytes(8)).digest(N)

def enc3(key, state, msg):
    offset = token_bytes(20)
    k = int.from_bytes(key)
    s = int.from_bytes(state)
    c = []
    for _i, b in enumerate(offset + msg):
        s <<= 8
        t = filter_k(k, s)
        c.append(t ^ b)
        s += t
        s <<= 8
        s += filter_2(s)
    return bytes(c)

iv = token_bytes(20)
print(f'alice to bob: {iv.hex()}')
iv = bytes(a ^ b for a, b in zip(iv, bytes.fromhex(input(f'bob to alice: '))))
print(f'alice to bob: {enc3(key3, iv, FLAG).hex()}')